Steps to change input in the file-

Step 1: Open the file "inp-params.txt"
Step 2: Change n and m respectively (separated by space)

Note: By default, input is N=1000000 and m=10


-------------------------------------------------------------------


Steps to run main program i.e, DAM1 .

Step 1 : g++ DAM1-CS2MTECH02001.cpp -pthread
Step 2 : ./a.out


-------------------------------------------------------------------


Steps to run main program i.e, SAM1 .

Step 1 : g++ SAM1-CS2MTECH02001.cpp -pthread
Step 2 : ./a.out


------------------------------------------------------------------

Check output in following files-

1. DAM1.txt
2. SAM1.txt
4. Times.txt        (for DAM1 and SAM1)

Note: Time will be displayed in microsecond

-------------------------------------------------------------------

Varify the graph you can run the python script.

step1: python3 run10.py
